import React from 'react';
import App from '../App'; // <-- caminho correto

const Dashboard = () => {
  return <App />;
};

export default Dashboard;
