from flask import Flask
from flask_cors import CORS
from flask_jwt_extended import JWTManager

from src.models.database import db
from src.routes.auth import auth_bp
import os
os.environ["FLASK_ENV"] = "development"


app = Flask(__name__)
app.config['DEBUG'] = True
app.config['ENV'] = 'development'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///apollo.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'sua-chave-jwt-segura'
app.debug = True

# Inicializar extensões
db.init_app(app)
jwt = JWTManager(app)
CORS(app)

# Registrar rotas
app.register_blueprint(auth_bp, url_prefix='/api/auth')

@app.route('/')
def index():
    return 'Apollo API está no ar!'

if __name__ == '__main__':
    app.run(debug=True)
