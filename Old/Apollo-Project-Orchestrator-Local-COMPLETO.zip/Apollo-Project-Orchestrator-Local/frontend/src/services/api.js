// Configuração da API
const API_BASE_URL = 'http://localhost:5000/api';

// Classe para gerenciar autenticação
class AuthService {
  static getToken() {
    return localStorage.getItem('apollo_access_token');
  }

  static setToken(token) {
    localStorage.setItem('apollo_access_token', token);
  }

  static getRefreshToken() {
    return localStorage.getItem('apollo_refresh_token');
  }

  static setRefreshToken(token) {
    localStorage.setItem('apollo_refresh_token', token);
  }

  static removeTokens() {
    localStorage.removeItem('apollo_access_token');
    localStorage.removeItem('apollo_refresh_token');
    localStorage.removeItem('apollo_user');
  }

  static getUser() {
    const user = localStorage.getItem('apollo_user');
    return user ? JSON.parse(user) : null;
  }

  static setUser(user) {
    localStorage.setItem('apollo_user', JSON.stringify(user));
  }

  static isAuthenticated() {
    return !!this.getToken();
  }
}

// Classe para fazer requisições à API
class ApiService {
  static async request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const token = AuthService.getToken();

    const config = {
      headers: {
        'Content-Type': 'application/json',
        ...(token && { Authorization: `Bearer ${token}` }),
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (response.status === 401 && token) {
        // Token expirado, tentar renovar
        const refreshed = await this.refreshToken();
        if (refreshed) {
          // Tentar novamente com o novo token
          config.headers.Authorization = `Bearer ${AuthService.getToken()}`;
          return await fetch(url, config);
        } else {
          // Refresh falhou, fazer logout
          AuthService.removeTokens();
          window.location.reload();
          return;
        }
      }

      return response;
    } catch (error) {
      console.error('Erro na requisição:', error);
      throw error;
    }
  }

  static async refreshToken() {
    const refreshToken = AuthService.getRefreshToken();
    if (!refreshToken) return false;

    try {
      const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${refreshToken}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        AuthService.setToken(data.access_token);
        return true;
      }
    } catch (error) {
      console.error('Erro ao renovar token:', error);
    }

    return false;
  }

  // Métodos de autenticação
  static async register(userData) {
    const response = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
    return response.json();
  }

  static async login(credentials) {
    const response = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
    
    if (response.ok) {
      const data = await response.json();
      AuthService.setToken(data.access_token);
      AuthService.setRefreshToken(data.refresh_token);
      AuthService.setUser(data.user);
    }
    
    return response.json();
  }

  static async logout() {
    try {
      await this.request('/auth/logout', { method: 'POST' });
    } finally {
      AuthService.removeTokens();
    }
  }

  static async getCurrentUser() {
    const response = await this.request('/auth/me');
    return response.json();
  }

  // Métodos de projetos
  static async getProjects() {
    const response = await this.request('/projects');
    return response.json();
  }

  static async createProject(projectData) {
    const response = await this.request('/projects', {
      method: 'POST',
      body: JSON.stringify(projectData),
    });
    return response.json();
  }

  static async getProject(projectId) {
    const response = await this.request(`/projects/${projectId}`);
    return response.json();
  }

  static async updateProject(projectId, projectData) {
    const response = await this.request(`/projects/${projectId}`, {
      method: 'PUT',
      body: JSON.stringify(projectData),
    });
    return response.json();
  }

  static async deleteProject(projectId) {
    const response = await this.request(`/projects/${projectId}`, {
      method: 'DELETE',
    });
    return response.json();
  }

  static async updateProjectStep(projectId, stepNumber, stepData) {
    const response = await this.request(`/projects/${projectId}/steps/${stepNumber}`, {
      method: 'PUT',
      body: JSON.stringify(stepData),
    });
    return response.json();
  }

  // Métodos de usuários
  static async getUserProfile() {
    const response = await this.request('/users/profile');
    return response.json();
  }

  static async updateUserProfile(userData) {
    const response = await this.request('/users/profile', {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
    return response.json();
  }

  // Métodos de IA
  static async analyzeDocuments(projectData) {
    const response = await this.request('/ai/analyze-documents', {
      method: 'POST',
      body: JSON.stringify(projectData),
    });
    return response.json();
  }

  static async checkAIHealth() {
    const response = await this.request('/ai/health');
    return response.json();
  }
}

export { AuthService, ApiService };

