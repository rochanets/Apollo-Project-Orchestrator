from src.models.database import db, User
from src.main import app
from werkzeug.security import generate_password_hash

with app.app_context():
    # Verificar se o usuário já existe para evitar duplicidade
    existing_user = User.query.filter_by(email='hfnetto@stefanini.om').first()
    if not existing_user:
        user = User(
            name='hfnetto',
            email='hfnetto@stefanini.om',
            password_hash=generate_password_hash('teste123')
        )
        db.session.add(user)
        db.session.commit()
        print('Usuário hfnetto@stefanini.om adicionado com sucesso.')
    else:
        print('Usuário hfnetto@stefanini.om já existe no banco de dados.')

