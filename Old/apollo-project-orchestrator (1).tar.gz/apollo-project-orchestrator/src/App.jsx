import React, { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { 
  CheckCircle, 
  Circle, 
  FolderOpen, 
  Plus, 
  Settings,
  User,
  FileText,
  Upload,
  MessageSquare,
  Database,
  Code,
  TestTube,
  Rocket
} from 'lucide-react';
import apolloLogo from './assets/apollo-logo.png';
import './App.css';

// Dados das etapas do projeto
const projectSteps = [
  { id: 0, title: 'Cadastro do Projeto', icon: FileText, description: 'Informações básicas do projeto' },
  { id: 1, title: 'Upload de Documentos', icon: Upload, description: 'Anexar documentação do projeto' },
  { id: 2, title: 'Geração de Perguntas', icon: MessageSquare, description: 'IA gera perguntas críticas' },
  { id: 3, title: 'Coleta de Informações', icon: Database, description: 'Documentação e esclarecimentos' },
  { id: 4, title: 'Análise Técnica', icon: Settings, description: 'Levantamento do ambiente' },
  { id: 5, title: 'Execução do Projeto', icon: Code, description: 'Desenvolvimento automatizado' },
  { id: 6, title: 'Testes', icon: TestTube, description: 'Testes integrados e correções' },
  { id: 7, title: 'Go Live', icon: Rocket, description: 'Documentação final e deploy' }
];

// Dados de exemplo de projetos
const sampleProjects = [
  { id: 1, name: 'Sistema de Vendas', client: 'Empresa ABC', status: 'Em andamento', currentStep: 3 },
  { id: 2, name: 'Portal do Cliente', client: 'Tech Corp', status: 'Concluído', currentStep: 7 },
  { id: 3, name: 'App Mobile', client: 'StartupXYZ', status: 'Pausado', currentStep: 1 }
];

function App() {
  const [selectedProject, setSelectedProject] = useState(sampleProjects[0]);
  const [currentStep, setCurrentStep] = useState(3);

  const getStepStatus = (stepId) => {
    if (stepId < currentStep) return 'completed';
    if (stepId === currentStep) return 'current';
    return 'pending';
  };

  const getProgressPercentage = () => {
    return ((currentStep + 1) / projectSteps.length) * 100;
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center space-x-4">
            <img src={apolloLogo} alt="Apollo Logo" className="h-10 w-10" />
            <div>
              <h1 className="text-xl font-bold text-primary">Apollo Project Orchestrator</h1>
              <p className="text-sm text-muted-foreground">Gestão Inteligente de Projetos</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <User className="h-4 w-4 mr-2" />
              Usuário
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-80 border-r border-border bg-sidebar min-h-screen">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-sidebar-foreground">Meus Projetos</h2>
              <Button size="sm" className="bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4 mr-2" />
                Novo
              </Button>
            </div>
            
            <div className="space-y-3">
              {sampleProjects.map((project) => (
                <Card 
                  key={project.id} 
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedProject.id === project.id ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedProject(project)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-sm">{project.name}</h3>
                        <p className="text-xs text-muted-foreground mt-1">{project.client}</p>
                        <div className="flex items-center mt-2">
                          <Badge 
                            variant={project.status === 'Concluído' ? 'default' : 
                                   project.status === 'Em andamento' ? 'secondary' : 'outline'}
                            className="text-xs"
                          >
                            {project.status}
                          </Badge>
                        </div>
                      </div>
                      <FolderOpen className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Progress Bar */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{selectedProject.name}</span>
                <Badge variant="secondary">Etapa {currentStep + 1} de {projectSteps.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Progress value={getProgressPercentage()} className="h-2" />
                
                {/* Steps */}
                <div className="grid grid-cols-4 gap-4 mt-6">
                  {projectSteps.map((step) => {
                    const status = getStepStatus(step.id);
                    const StepIcon = step.icon;
                    
                    return (
                      <div key={step.id} className="flex flex-col items-center text-center space-y-2">
                        <div className={`relative flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all ${
                          status === 'completed' 
                            ? 'bg-green-500 border-green-500 text-white' 
                            : status === 'current'
                            ? 'bg-primary border-primary text-primary-foreground scale-110'
                            : 'border-muted-foreground text-muted-foreground'
                        }`}>
                          {status === 'completed' ? (
                            <CheckCircle className="h-6 w-6" />
                          ) : status === 'current' ? (
                            <StepIcon className="h-6 w-6" />
                          ) : (
                            <Circle className="h-6 w-6" />
                          )}
                          <span className="absolute -top-2 -right-2 bg-background border border-border rounded-full w-6 h-6 flex items-center justify-center text-xs font-medium">
                            {step.id}
                          </span>
                        </div>
                        <div>
                          <p className={`text-sm font-medium ${
                            status === 'current' ? 'text-primary' : 'text-foreground'
                          }`}>
                            {step.title}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {step.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Current Step Content */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                {React.createElement(projectSteps[currentStep].icon, { className: "h-5 w-5 text-primary" })}
                <span>{projectSteps[currentStep].title}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  {projectSteps[currentStep].description}
                </p>
                
                {currentStep === 3 && (
                  <div className="space-y-4">
                    <h3 className="font-medium">Coleta de Informações Funcionais</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card className="p-4">
                        <h4 className="font-medium mb-2">Documentação Básica</h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          IA gera perguntas base iniciais com base nos documentos
                        </p>
                        <Button size="sm" variant="outline">
                          Ver Perguntas
                        </Button>
                      </Card>
                      <Card className="p-4">
                        <h4 className="font-medium mb-2">Reunião de Esclarecimentos</h4>
                        <p className="text-sm text-muted-foreground mb-3">
                          IA coleta insights adicionais durante a reunião
                        </p>
                        <Button size="sm" variant="outline">
                          Agendar Reunião
                        </Button>
                      </Card>
                    </div>
                  </div>
                )}
                
                <div className="flex space-x-2 pt-4">
                  <Button 
                    onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                    disabled={currentStep === 0}
                    variant="outline"
                  >
                    Anterior
                  </Button>
                  <Button 
                    onClick={() => setCurrentStep(Math.min(projectSteps.length - 1, currentStep + 1))}
                    disabled={currentStep === projectSteps.length - 1}
                    className="bg-primary hover:bg-primary/90"
                  >
                    Próxima Etapa
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </main>
      </div>
    </div>
  );
}

export default App;

